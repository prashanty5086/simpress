-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 08, 2019 at 02:19 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `user_id`, `name`, `created_at`) VALUES
(1, 0, 'advertising', '2019-06-08 06:49:04'),
(2, 1, 'Printing', '2019-06-08 06:49:42'),
(3, 1, 'Press', '2019-06-08 09:06:03');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `name`, `email`, `body`, `created_at`) VALUES
(0, 2, 'aaaaaaaaaa', 'jj@gmail.com', 'sssssssssss', '2019-06-08 07:31:43');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `post_image` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `category_id`, `user_id`, `title`, `slug`, `body`, `post_image`, `created_at`) VALUES
(1, 1, 2, 'Hello', 'Hello', '<p>aaaaaaaaaaaaaaaaaaaaa</p>\r\n', 'noimage.jpg', '2019-06-08 06:50:28'),
(2, 1, 1, 'Hi ', 'Hi', '<p>kkkkkkkkkkkkkkkkkk</p>\r\n', 'Chrysanthemum.jpg', '2019-06-08 07:27:24'),
(3, 1, 4, 'Welcome', 'Welcome', '<p>aaaaaaaaaaaaaaaaaaaaaaaaa</p>\r\n', 'noimage.jpg', '2019-06-08 08:26:04'),
(5, 1, 6, 'wwwwwwww', 'wwwwwwww', '<p>ssssssssssssss</p>\r\n', 'Hydrangeas.jpg', '2019-06-08 09:59:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `zipcode` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_type` tinyint(1) NOT NULL,
  `password` varchar(400) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `zipcode`, `email`, `username`, `user_type`, `password`, `register_date`) VALUES
(1, 'Prashant', '401105', 'prashant5086@gmail.com', 'prashant5086', 1, '6ca13d52ca70c883e0f0bb101e425a89e8624de51db2d2392593af6a84118090', '2019-06-08 06:32:33'),
(2, 'rahul', '401105', 'rahul@gmail.com', 'rahul', 0, '6ca13d52ca70c883e0f0bb101e425a89e8624de51db2d2392593af6a84118090', '2019-06-08 06:45:40'),
(3, 'vijay', '401105', 'vijay@gmail.com', 'vijay5086', 0, '6ca13d52ca70c883e0f0bb101e425a89e8624de51db2d2392593af6a84118090', '2019-06-08 07:16:37'),
(4, 'aaa', '401105', 'aaaa@gmail.com', 'aaa', 0, '9834876dcfb05cb167a5c24953eba58c4ac89b1adf57f28f2f9d09af107ee8f0', '2019-06-08 07:18:13'),
(5, 'cimpress', '401105', 'cimpress@gmail.com', 'cimpress', 0, '6ca13d52ca70c883e0f0bb101e425a89e8624de51db2d2392593af6a84118090', '2019-06-08 07:24:46'),
(6, 'mmm', '401105', 'mmm@gmail.com', 'mmm', 0, '6ca13d52ca70c883e0f0bb101e425a89e8624de51db2d2392593af6a84118090', '2019-06-08 09:58:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
